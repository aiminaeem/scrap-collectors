package com.example.eproject;

public class Admin {

    public int id;
    public String name;
    public String password;

    public Admin(String name, String password) {
        this.name = name;
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getPassword() {
        return password;
    }
}
