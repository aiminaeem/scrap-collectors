package com.example.eproject;

public class Appointment {

    public int id;
    public String product_type;
    public String date;
    public String time;
    public String user_name;
    public String address;

    public Appointment(String product_type, String date, String time, String user_name, String address) {
        this.product_type = product_type;
        this.date = date;
        this.time = time;
        this.user_name = user_name;
        this.address = address;
    }

    public Appointment(int id, String product_type, String date, String time, String user_name, String address) {
    }

    public int getId() {
        return id;
    }

    public String getProduct_type() {
        return product_type;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getUser_name() {
        return user_name;
    }

    public String getAddress() {
        return address;
    }
}
