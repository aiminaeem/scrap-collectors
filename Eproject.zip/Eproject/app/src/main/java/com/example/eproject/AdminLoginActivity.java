package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AdminLoginActivity extends AppCompatActivity {

    EditText ad_name, ad_pass;
    Button btnLogin, btnback;

    MyDatabase mydb;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        mydb = new MyDatabase(this);

        ad_name = findViewById(R.id.admin_name);
        ad_pass = findViewById(R.id.admin_pass);
        btnLogin = findViewById(R.id.adminlogin);
        btnback = findViewById(R.id.back);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AdminLoginActivity.this, FirstpageActivity.class);
                startActivity(intent);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = ad_name.getText().toString();
                String password = ad_pass.getText().toString();

                if (name.equals("Admin") && password.equals("admin123")) {
                    Intent in = new Intent(AdminLoginActivity.this, AdminWelcomeActivity.class);
                    startActivity(in);
                } else if (name.equals("") && password.equals("")) {

                    Toast.makeText(AdminLoginActivity.this, "Enter your name & password", Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(AdminLoginActivity.this, "Wrong Name & Password", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}