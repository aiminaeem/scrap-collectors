package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.eproject.MyDatabase.Table_name2;
import static com.example.eproject.MyDatabase.U_EMAIL;
import static com.example.eproject.MyDatabase.U_PASS;

public class UserLoginActivity extends AppCompatActivity {

    EditText u_email , u_pass;
    Button btnLogin , btnback;
    MyDatabase mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        mydb = new MyDatabase(this);

        u_email = findViewById(R.id.ed_email1);
        u_pass = findViewById(R.id.ed_pass1);
        btnback = findViewById(R.id.back);
        btnLogin = findViewById(R.id.ULogin);

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserLoginActivity.this ,FirstpageActivity.class);
                startActivity(intent);
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                String email = u_email.getText().toString();
                String password = u_pass.getText().toString();

                SQLiteDatabase db;
                Cursor cursor = null;

                try{

                    db = mydb.getReadableDatabase();
                    cursor = db.rawQuery("Select * from "+Table_name2+ " where " +U_EMAIL +" = ? and "
                            +U_PASS+ " = ?" , new String[]{email,password});

                    if(cursor.moveToFirst())
                    {
                        Intent intent = new Intent(UserLoginActivity.this , UserWelcomeActivity.class);
                        startActivity(intent);
                    }

                    else
                    {
                        Toast.makeText(UserLoginActivity.this, "Please try again", Toast.LENGTH_SHORT).show();

                    }


                }

                catch (Exception ex)
                {

                }

            }
        });


    }
}