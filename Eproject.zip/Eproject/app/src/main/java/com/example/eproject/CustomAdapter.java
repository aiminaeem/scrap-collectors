package com.example.eproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter {

    ArrayList<ScrapItems> arrayList;
    Context context;

    public CustomAdapter(@NonNull Context context, ArrayList<ScrapItems> arrayList){
        super(context, 0, arrayList);
        this.arrayList = arrayList;
        this.context = context;
    }
    @Override
    public int getCount() {return arrayList.size();}
    @NonNull
    @Override

    public View getView(int position , @Nullable View convertView, @NonNull ViewGroup parent){
        View view = LayoutInflater.from(context).inflate((R.layout.list_view_scrapitem), parent, false);

        final ScrapItems scrapitems = arrayList.get(position);

        TextView price = view.findViewById(R.id.i_price);
        TextView item = view.findViewById(R.id.i_type);
        TextView weight = view.findViewById(R.id.i_weight);


        price.setText(scrapitems.getPrice());
        item.setText(scrapitems.getItem());
        weight.setText(scrapitems.getWeight());


        return view;


    }





}


