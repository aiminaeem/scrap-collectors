package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class FirstpageActivity extends AppCompatActivity {

    Button user_reg , user_login, admin , scrap_reg , scrap_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_firstpage);


        user_reg = findViewById(R.id.r_user);
        scrap_reg = findViewById(R.id.r_scrap);
        admin = findViewById(R.id.l_admin);
        user_login = findViewById(R.id.l_user);
        scrap_login = findViewById(R.id.l_scrap);



        user_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(FirstpageActivity.this , UserRegistrationActivity.class);
                startActivity(intent);

            }
        });


        scrap_reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(FirstpageActivity.this ,ScrapRegistrationActivity.class);
                startActivity(intent);
            }
        });


        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(FirstpageActivity.this , AdminLoginActivity.class);
                startActivity(intent);


            }
        });


        user_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(FirstpageActivity.this , UserLoginActivity.class);
                startActivity(intent);

            }
        });

        scrap_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(FirstpageActivity.this , ScrapLoginActivity.class);
                startActivity(intent);

            }
        });
    }
}