package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ScrapRegistrationActivity extends AppCompatActivity {

    EditText sc_name , sc_email , sc_pass , sc_contact;
    Button btnsignup , btnback;

    MyDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrap_registration);

        mydb = new MyDatabase(this);

        sc_name = findViewById(R.id.scname);
        sc_email = findViewById(R.id.scemail);
        sc_pass = findViewById(R.id.scpass);
        sc_contact = findViewById(R.id.sccontact);


        btnback = findViewById(R.id.back);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScrapRegistrationActivity.this ,FirstpageActivity.class);
                startActivity(intent);
            }
        });

        btnsignup = findViewById(R.id.btnSubmit1);
        btnsignup.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                String name = sc_name.getText().toString();
                String email = sc_email.getText().toString();
                String password = sc_pass.getText().toString();
                String contact = sc_contact.getText().toString();

                Scrap scrap = new Scrap(name , email , password , contact);

                long a = mydb.insert_ScrapCollector(scrap);

                if(a > 0)
                {
                    Toast.makeText(getApplicationContext(), "Sign up Successfully" , Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(ScrapRegistrationActivity.this ,ScrapLoginActivity.class);
                    startActivity(intent);
                }

                else
                {
                    Toast.makeText(getApplicationContext(), "Try Again" , Toast.LENGTH_SHORT).show();

                }

            }



        });


    }
}