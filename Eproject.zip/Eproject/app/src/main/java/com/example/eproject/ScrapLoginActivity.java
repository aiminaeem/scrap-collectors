package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import static com.example.eproject.MyDatabase.SC_EMAIL;
import static com.example.eproject.MyDatabase.SC_PASS;
import static com.example.eproject.MyDatabase.Table_name3;

public class ScrapLoginActivity extends AppCompatActivity {

    EditText sc_email , sc_pass;
    Button btnLogin , btnback;
    MyDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrap_login);

        mydb = new MyDatabase(this);

        sc_email = findViewById(R.id.scemail);
        sc_pass = findViewById(R.id.scpass);
        btnLogin = findViewById(R.id.SLogin);
        btnback = findViewById(R.id.back);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScrapLoginActivity.this ,FirstpageActivity.class);
                startActivity(intent);
            }
        });


        btnLogin.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {

                String email = sc_email.getText().toString();
                String password = sc_pass.getText().toString();

                SQLiteDatabase db;
                Cursor cursor = null;

                try{

                    db = mydb.getReadableDatabase();
                    cursor = db.rawQuery("Select * from "+Table_name3+ " where " +SC_EMAIL +" = ? and "
                            +SC_PASS+ " = ?" , new String[]{email,password});

                    if(cursor.moveToFirst())
                    {
                        Intent intent = new Intent(ScrapLoginActivity.this , ScrapWelcomeActivity.class);
                        startActivity(intent);
                    }

                    else
                    {
                        Toast.makeText(ScrapLoginActivity.this, "Please try again", Toast.LENGTH_SHORT).show();
                    }
     }
                catch (Exception ex)
                {

                }
            }
        });
    }
}