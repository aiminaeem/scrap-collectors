package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ScrapWelcomeActivity extends AppCompatActivity {

    Button btnback, showappoint , checkitems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrap_welcome);

        showappoint = findViewById(R.id.btnvp);
        checkitems = findViewById(R.id.btncitem);
        btnback = findViewById(R.id.back);



        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScrapWelcomeActivity.this ,ScrapRegistrationActivity.class);
                startActivity(intent);
            }
        });


        showappoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScrapWelcomeActivity.this ,ShowAppointment.class);
                startActivity(intent);
            }
        });



        checkitems.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScrapWelcomeActivity.this ,ScrapShowData.class);
                startActivity(intent);
            }
        });



    }
}