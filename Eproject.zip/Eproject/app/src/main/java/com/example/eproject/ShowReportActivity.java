package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class ShowReportActivity extends AppCompatActivity {


    ArrayList<Appointment> arrayList;
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_report);

        list = findViewById(R.id.list);

        MyDatabase my = new MyDatabase(this);
        arrayList =   my.fetch_Appointment();

        CustomAdapter1 adapter = new CustomAdapter1(this,arrayList);
        list.setAdapter(adapter);

    }
}