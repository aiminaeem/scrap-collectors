package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class UserWelcomeActivity extends AppCompatActivity {

    Button bookappoint, checkrates, genreports, btnback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_welcome);

        bookappoint = findViewById(R.id.btnbp);
        checkrates = findViewById(R.id.btncr);
        genreports = findViewById(R.id.btngr);
        btnback = findViewById(R.id.back);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserWelcomeActivity.this, UserRegistrationActivity.class);
                startActivity(intent);
            }
        });


        bookappoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserWelcomeActivity.this, BookAppointmentActivity.class);
                startActivity(intent);
            }
        });

        checkrates.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserWelcomeActivity.this, ScrapShowData.class);
                startActivity(intent);
            }
        });

        genreports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserWelcomeActivity.this, ShowReportActivity.class);
                startActivity(intent);
            }
        });
    }
}