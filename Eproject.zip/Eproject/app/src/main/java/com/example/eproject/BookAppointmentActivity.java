package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BookAppointmentActivity extends AppCompatActivity {


    EditText p_type, b_date , b_time , u_name , u_address;
    Button btncreate , btnback;

    MyDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_appointment);

        mydb = new MyDatabase(this);

        p_type = findViewById(R.id.ed_protype);
        b_date = findViewById(R.id.ed_date);
        b_time = findViewById(R.id.ed_time);
        u_name = findViewById(R.id.ed_uname);
        u_address = findViewById(R.id.ed_address);
        btnback = findViewById(R.id.back);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BookAppointmentActivity.this ,UserWelcomeActivity.class);
                startActivity(intent);
            }
        });

        btncreate = findViewById(R.id.BALogin);
        btncreate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String product_type = p_type.getText().toString();
                String date = b_date.getText().toString();
                String time = b_time.getText().toString();
                String user_name = u_name.getText().toString();
                String address = u_address.getText().toString();

                Appointment appointment = new Appointment(product_type, date, time,user_name,address);

                long a = mydb.insert_Appointment(appointment);

                if (a > 0) {
                    Toast.makeText(getApplicationContext(), "Create Successfully Wait for Admin Approval", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(BookAppointmentActivity.this ,UserWelcomeActivity.class);
                    startActivity(intent);

                } else {
                    Toast.makeText(getApplicationContext(), "Try Again", Toast.LENGTH_SHORT).show();

                }

            }


        });


    }


}
