package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ScrapItemsActivity extends AppCompatActivity {

    EditText s_item, s_weight, s_price;
    Button btncreate , btnback;

    MyDatabase mydb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrap_items);

        mydb = new MyDatabase(this);

        s_item = findViewById(R.id.item);
        s_weight = findViewById(R.id.weight);
        s_price = findViewById(R.id.price);

        btnback = findViewById(R.id.back);
        btncreate = findViewById(R.id.btncitem);

        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScrapItemsActivity.this ,AdminWelcomeActivity.class);
                startActivity(intent);
            }
        });
        btncreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item = s_item.getText().toString();
                String weight = s_weight.getText().toString();
                String price = s_price.getText().toString();

                ScrapItems scrapitems = new ScrapItems(item, weight, price);

                long a = mydb.insert_ScrapItems(scrapitems);

                if (a > 0) {
                    Toast.makeText(getApplicationContext(), "Create Successfully", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Try Again", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}