package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UserRegistrationActivity extends AppCompatActivity {

    EditText u_name , u_email , u_pass , u_contact;
    Button btnsignup , btnback;
    MyDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        mydb = new MyDatabase(this);

        u_name = findViewById(R.id.ed_name);
        u_email = findViewById(R.id.ed_email);
        u_pass = findViewById(R.id.ed_password);
        u_contact = findViewById(R.id.ed_contact);
        btnback = findViewById(R.id.back);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserRegistrationActivity.this ,FirstpageActivity.class);
                startActivity(intent);
            }
        });


        btnsignup = findViewById(R.id.btnsignup);
        btnsignup.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {

                String name = u_name.getText().toString();
                String email = u_email.getText().toString();
                String password = u_pass.getText().toString();
                String contact = u_contact.getText().toString();

                User user = new User(name , email , password , contact);

                long a = mydb.insert_User(user);

                if(a > 0)
                {
                    Toast.makeText(getApplicationContext(), "Sign up Successfully" , Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(UserRegistrationActivity.this ,UserLoginActivity.class);
                    startActivity(intent);
                }

                else
                {
                    Toast.makeText(getApplicationContext(), "Try Again" , Toast.LENGTH_SHORT).show();

                }

            }



        });
    }
}