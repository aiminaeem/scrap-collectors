package com.example.eproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.util.ArrayList;

import static android.content.ContentValues.TAG;

public class MyDatabase extends SQLiteOpenHelper {

    public static final String Database_name = "mydb";


    public static final String Table_name1 = "Admin";
    public static final String AD_ID = "id";
    public static final String AD_NAME = "name";
    public static final String AD_PASS = "password";


    public static final String Table_name2 = "User";
    public static final String U_ID = "id";
    public static final String U_NAME = "name";
    public static final String U_EMAIL = "email";
    public static final String U_PASS = "password";
    public static final String U_CONTACT = "contact";


    public static final String Table_name3 = "Scrap_Collector";
    public static final String SC_ID = "id";
    public static final String SC_NAME = "name";
    public static final String SC_EMAIL = "email";
    public static final String SC_PASS = "password";
    public static final String SC_CONTACT = "contact";


    public static final String Table_name4 = "Scrap_Items";
    public static final String S_ID = "id";
    public static final String S_ITEM = "item";
    public static final String S_PRICE = "price";
    public static final String S_WEIGHT = "weight";


    public static final String Table_name5 = "Appointment";
    public static final String A_ID = "id";
    public static final String A_PRODUCT_TYPE = "product_type";
    public static final String A_DATE = "date";
    public static final String A_TIME = "time";
    public static final String A_USER_NAME = "user_name";
    public static final String A_ADDRESS = "address";


    public static final String Table_Admin = " Create Table " + Table_name1 + "(" + AD_ID + " INTEGER Primary key AUTOINCREMENT ," + AD_NAME + " text ," + AD_PASS + " text)";

    public static final String Table_User = " Create Table " + Table_name2 + "(" + U_ID + " INTEGER Primary key AUTOINCREMENT ," + U_NAME + " text ," + U_EMAIL + " text," + U_PASS + " text ," + U_CONTACT + " text)";

    public static final String Table_ScrapCollector = "Create Table " + Table_name3 +
            "(" + SC_ID + " INTEGER Primary key AUTOINCREMENT ," + SC_NAME + " text ,"
            + SC_EMAIL + " text ," + SC_PASS + " text ," + SC_CONTACT + " text)";

    public static final String Table_ScrapItems = "Create Table " + Table_name4 +
            "(" + S_ID + " INTEGER Primary key AUTOINCREMENT ," + S_ITEM + " text ,"
            + S_PRICE + " text ," + S_WEIGHT + " text)";

    public static final String Table_Appointment = "Create Table " + Table_name5 +
            "(" + A_ID + " INTEGER Primary key AUTOINCREMENT ," + A_PRODUCT_TYPE + " text ,"
            + A_DATE + " text ," + A_TIME + " text ," + A_USER_NAME + " text ," + A_ADDRESS + " text)";

    public MyDatabase(@Nullable Context context) {
        super(context, Database_name, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        try {
            db.execSQL(Table_Admin);
            db.execSQL(Table_User);
            db.execSQL(Table_ScrapCollector);
            db.execSQL(Table_ScrapItems);
            db.execSQL(Table_Appointment);
        } catch (Exception ex) {
            Log.d(TAG, "Creating Table Error" + ex);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public long insert_Admin(Admin admin)
    {
        SQLiteDatabase db;

        try{
            db = getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(AD_NAME , admin.getName());
            cv.put(AD_PASS , admin.getPassword());

            db.insert(Table_name1 , null , cv);
        }

        catch (Exception ex)
        {
        }
        return 1;
    }

    public long insert_User(User user)
    {
        SQLiteDatabase db;

        try {
            db = getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(U_NAME, user.getName());
            cv.put(U_EMAIL, user.getEmail());
            cv.put(U_PASS, user.getPassword());
            cv.put(U_CONTACT, user.getContact());

            db.insert(Table_name2, null, cv);

        }
        catch(Exception ex)
        {

        }

        return 1;

    }

    public long insert_ScrapCollector(Scrap scrap){

        SQLiteDatabase db;

        try {
            db = getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(SC_NAME, scrap.getName());
            cv.put(SC_EMAIL, scrap.getEmail());
            cv.put(SC_PASS, scrap.getPassword());
            cv.put(SC_CONTACT, scrap.getContact());

            db.insert(Table_name3, null, cv);
        }
        catch(Exception ex)
        {
        }
        return 1;

    }

    public long insert_ScrapItems(ScrapItems scrapitems){
        SQLiteDatabase db;

        try {
            db = getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(S_ITEM, scrapitems.getItem());
            cv.put(S_WEIGHT, scrapitems.getWeight());
            cv.put(S_PRICE, scrapitems.getPrice());


            db.insert(Table_name4, null, cv);

        }
        catch(Exception ex)
        {

        }

        return 0;

    }

    public long update_ScrapItems(ScrapItems scrapitems){

        SQLiteDatabase db = null;
        try {

            db = getWritableDatabase();
            ContentValues cv = new ContentValues();

            cv.put(S_ITEM, scrapitems.getItem());
            cv.put(S_WEIGHT, scrapitems.getWeight());
            cv.put(S_PRICE, scrapitems.getPrice());

            String where = S_ITEM + "=?";
            String[] whereArgs = new String[]{String.valueOf(scrapitems.getItem())};
            int a = db.update(Table_name4, cv, where, whereArgs);
        }
        catch (Exception ex) {
        }
        return 1;
    }


    public ArrayList<ScrapItems> fetch_ScrapItems() {

        SQLiteDatabase db = getReadableDatabase();
        ArrayList<ScrapItems> arrayList = new ArrayList<>();
        Cursor cursor;
        try {
            String sql = "select * from " + Table_name4;
            cursor = db.rawQuery(sql, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(cursor.getColumnIndex(S_ID));
                    String item = cursor.getString(cursor.getColumnIndex(S_ITEM));
                    String price = cursor.getString(cursor.getColumnIndex(S_PRICE));
                    String weight = cursor.getString(cursor.getColumnIndex(S_WEIGHT));


                    ScrapItems scrapitems = new ScrapItems(item, weight ,price);
                    arrayList.add(scrapitems);
                }
            }
        }
        catch (Exception ex){

        }

        return arrayList;

    }

    public long insert_Appointment(Appointment appointment){
        SQLiteDatabase db;

        try {
            db = getReadableDatabase();
            ContentValues cv = new ContentValues();
            cv.put(A_PRODUCT_TYPE, appointment.getProduct_type());
            cv.put(A_DATE, appointment.getDate());
            cv.put(A_TIME, appointment.getTime());
            cv.put(A_USER_NAME, appointment.getUser_name());
            cv.put(A_ADDRESS, appointment.getAddress());

            db.insert(Table_name5, null, cv);

        }
        catch(Exception ex)
        {

        }

        return 1;

    }

    public ArrayList<Appointment> fetch_Appointment() {

        SQLiteDatabase db = getReadableDatabase();
        ArrayList<Appointment> arrayList = new ArrayList<>();
        Cursor cursor;
        try {
            String sql = "select * from " + Table_name5;
            cursor = db.rawQuery(sql, null);
            if (cursor != null) {
                while (cursor.moveToNext()) {
                    int id = cursor.getInt(cursor.getColumnIndex(A_ID));
                    String product_type = cursor.getString(cursor.getColumnIndex(A_PRODUCT_TYPE));
                    String date = cursor.getString(cursor.getColumnIndex(A_DATE));
                    String time = cursor.getString(cursor.getColumnIndex(A_TIME));
                    String user_name = cursor.getString(cursor.getColumnIndex(A_USER_NAME));
                    String address = cursor.getString(cursor.getColumnIndex(A_ADDRESS));



                    Appointment appointment = new Appointment(id,product_type,date,time,user_name,address);
                    arrayList.add(appointment);
                }
            }
        }
        catch (Exception ex){

        }

        return arrayList;

    }
}

