package com.example.eproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Gallery;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class AdminWelcomeActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    DrawerLayout drawerLayout;
    ActionBarDrawerToggle drawerToggle;
  //  TextView addscrap, updatescrap, viewscrap, viewappoint, assignappoint, report;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_welcome);

        drawerLayout = (DrawerLayout) findViewById(R.id.nav);
        drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.Open,R.string.Close);

        drawerLayout.addDrawerListener(drawerToggle);
        drawerToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView = findViewById(R.id.mainNav);
        navigationView.setNavigationItemSelectedListener(this);


    //    addscrap = findViewById(R.id.addscrap);
      //  updatescrap = findViewById(R.id.updatescrap);
       // viewscrap = findViewById(R.id.viewscrap);
        //viewappoint = findViewById(R.id.Viewappoint);
        //assignappoint = findViewById(R.id.Asignappoint);
        // report = findViewById(R.id.report);


        // addscrap.setOnClickListener(new View.OnClickListener() {
        //   @Override
        //  public void onClick(View v) {
        //     Intent intent = new Intent(AdminWelcomeActivity.this, ScrapItemsActivity.class);
        //     startActivity(intent);
        //  }});
        //  updatescrap.setOnClickListener(new View.OnClickListener() {
        //   @Override
        //    public void onClick(View v) {
        ///       Intent intent = new Intent(AdminWelcomeActivity.this, ScrapItemUpdateActivity.class);
        //       startActivity(intent);

        //     }
        // });

        // viewscrap.setOnClickListener(new View.OnClickListener() {
        //    @Override
        //   public void onClick(View v) {
        //     Intent intent = new Intent(AdminWelcomeActivity.this, ScrapShowData.class);
        //    startActivity(intent);

        ///  }
        //  });

        ///  viewappoint.setOnClickListener(new View.OnClickListener() {
        ///   @Override
        //   public void onClick(View v) {
        //      Intent intent = new Intent(AdminWelcomeActivity.this, ShowAppointment.class);
        //   startActivity(intent);

        // }
        //  });


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       if (drawerToggle.onOptionsItemSelected(item)) {

           return true;

        }


       return super.onOptionsItemSelected(item);
    }

    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();
        Bundle bundle = new Bundle();
        if (id == R.id.mainNav) {
        } else if (id == R.id.addscrap) {
            Intent intent = new Intent(AdminWelcomeActivity.this,ScrapItemsActivity .class);
            startActivity(intent);
        } else if (id == R.id.updatescrap) {
            Intent intent = new Intent(AdminWelcomeActivity.this,ScrapItemUpdateActivity .class);
            startActivity(intent);
        } else if (id == R.id.viewscrap) {
            Intent intent = new Intent(AdminWelcomeActivity.this,ScrapShowData .class);
            startActivity(intent);
        }
     else if (id == R.id.Viewappoint) {
            Intent intent = new Intent(AdminWelcomeActivity.this,ShowAppointment .class);
            startActivity(intent);
    }
     else if (id == R.id.Asignappoint) {
            Intent intent = new Intent(AdminWelcomeActivity.this,BookAppointmentActivity .class);
            startActivity(intent);
        }


        else if (id == R.id.report) {
            Intent intent = new Intent(AdminWelcomeActivity.this,ShowReportActivity .class);
            startActivity(intent);
        }

        return true;
    }}
