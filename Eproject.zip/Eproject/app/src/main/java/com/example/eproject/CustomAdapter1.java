package com.example.eproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class CustomAdapter1 extends ArrayAdapter {

    ArrayList<Appointment> arrayList;
    Context context;

    public CustomAdapter1(@NonNull Context context, ArrayList<Appointment> arrayList){
        super(context,0, arrayList);
        this.arrayList = arrayList;
        this.context = context;
    }
    @Override
    public int getCount() {return arrayList.size();}
    @NonNull
    @Override

    public View getView(int position1 , @Nullable View convertView, @NonNull ViewGroup parent){
        View view = LayoutInflater.from(context).inflate((R.layout.listview_appointment), parent, false);

        final Appointment appointment = arrayList.get(position1);

        TextView product_type = view.findViewById(R.id.Product);
        TextView date = view.findViewById(R.id.Date);
        TextView time = view.findViewById(R.id.Time);
        TextView user_name = view.findViewById(R.id.User_name);
        TextView address = view.findViewById(R.id.Address);


        product_type.setText(appointment.getProduct_type());
        date.setText(appointment.getDate());
        time.setText(appointment.getTime());
        user_name.setText(appointment.getUser_name());
        address.setText(appointment.getAddress());


        return view;


    }


}
