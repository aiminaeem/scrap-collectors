package com.example.eproject;

public class ScrapItems {

    public int id;
    public String item;
    public String weight;
    public String price;

    public ScrapItems(String item, String weight, String price) {
        this.item = item;
        this.weight = weight;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getItem() {
        return item;
    }

    public String getWeight() {
        return weight;
    }

    public String getPrice() {
        return price;
    }
}
