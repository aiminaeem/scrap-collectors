package com.example.eproject;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ScrapShowData extends AppCompatActivity {

    ArrayList<ScrapItems> arrayList;
    ListView list;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_view_scrapitem);

        list = findViewById(R.id.list);

        MyDatabase mydb = new MyDatabase(this);
        arrayList =   mydb.fetch_ScrapItems();

        CustomAdapter adapter = new CustomAdapter(this,arrayList);
        list.setAdapter(adapter);



    }
}
