package com.example.eproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ScrapItemUpdateActivity extends AppCompatActivity {

    EditText u_item, u_weight, u_price;
    Button btnupdate , btnback;

    MyDatabase mydb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scrap_item_update);

        mydb = new MyDatabase(this);

        u_item = findViewById(R.id.item);
        u_weight = findViewById(R.id.weight);
        u_price = findViewById(R.id.price);

        btnback = findViewById(R.id.back);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScrapItemUpdateActivity.this ,AdminWelcomeActivity.class);
                startActivity(intent);
            }
        });

        btnupdate = findViewById(R.id.btnUpdate);
        btnupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String item = u_item.getText().toString();
                String weight = u_weight.getText().toString();
                String price = u_price.getText().toString();

                ScrapItems scrapitems = new ScrapItems(item, weight, price);


                long a = mydb.update_ScrapItems(scrapitems);
                if(a > 0)
                {
                    Toast.makeText(getApplicationContext(), "Data updated Successfully" , Toast.LENGTH_SHORT).show();
                }

                else
                {
                    Toast.makeText(ScrapItemUpdateActivity.this, "Try Again", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
}