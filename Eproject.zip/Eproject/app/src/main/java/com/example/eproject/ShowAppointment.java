package com.example.eproject;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ShowAppointment extends AppCompatActivity {

    ArrayList<Appointment> arrayList;
    ListView list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.listview_appointment);

        list = findViewById(R.id.list);

        MyDatabase mydb = new MyDatabase(this);
        arrayList = mydb.fetch_Appointment();

        CustomAdapter1 adapter = new CustomAdapter1(this, arrayList);
        list.setAdapter(adapter);
    }

}
